export declare const VERSION = "0.131.0";
//# sourceMappingURL=version.d.mts.map