import { castToError } from '../internal/errors';
import type { ErrorType } from '../resources/shared';

export class AnthropicError extends Error {}

export class APIError<
  TStatus extends number | undefined = number | undefined,
  THeaders extends Headers | undefined = Headers | undefined,
  TError extends Object | undefined = Object | undefined,
> extends AnthropicError {
  /** HTTP status for the response that caused the error */
  readonly status: TStatus;
  /** HTTP headers for the response that caused the error */
  readonly headers: THeaders;
  /** JSON body of the response that caused the error */
  readonly error: TError;

  readonly requestID: string | null | undefined;
  readonly workspaceID: string | null | undefined;

  /** The `error.type` from the API response body, e.g. `"rate_limit_error"` */
  readonly type: ErrorType | null;

  constructor(
    status: TStatus,
    error: TError,
    message: string | undefined,
    headers: THeaders,
    type?: ErrorType | null,
  ) {
    super(`${APIError.makeMessage(status, error, message)}`);
    this.status = status;
    this.headers = headers;
    this.requestID = headers?.get('request-id');
    this.workspaceID = headers?.get('anthropic-workspace-id');
    this.error = error;
    this.type = type ?? null;
  }

  private static makeMessage(status: number | undefined, error: any, message: string | undefined) {
    const msg =
      error?.message ?
        typeof error.message === 'string' ?
          error.message
        : JSON.stringify(error.message)
      : error ? JSON.stringify(error)
      : message;

    if (status && msg) {
      return `${status} ${msg}`;
    }
    if (status) {
      return `${status} status code (no body)`;
    }
    if (msg) {
      return msg;
    }
    return '(no status code or body)';
  }

  static generate(
    status: number | undefined,
    errorResponse: Object | undefined,
    message: string | undefined,
    headers: Headers | undefined,
  ): APIError {
    if (!status || !headers) {
      return new APIConnectionError({ message, cause: castToError(errorResponse) });
    }

    const error = errorResponse as Record<string, any>;
    const type = error?.['error']?.['type'] as ErrorType | undefined;

    if (status === 400) {
      return new BadRequestError(status, error, message, headers, type);
    }

    if (status === 401) {
      return new AuthenticationError(status, error, message, headers, type);
    }

    if (status === 403) {
      return new PermissionDeniedError(status, error, message, headers, type);
    }

    if (status === 404) {
      return new NotFoundError(status, error, message, headers, type);
    }

    if (status === 409) {
      return new ConflictError(status, error, message, headers, type);
    }

    if (status === 422) {
      return new UnprocessableEntityError(status, error, message, headers, type);
    }

    if (status === 429) {
      return new RateLimitError(status, error, message, headers, type);
    }

    if (status >= 500) {
      return new InternalServerError(status, error, message, headers, type);
    }

    return new APIError(status, error, message, headers, type);
  }
}

export class APIUserAbortError extends APIError<undefined, undefined, undefined> {
  constructor({ message }: { message?: string } = {}) {
    super(undefined, undefined, message || 'Request was aborted.', undefined);
  }
}

export class APIConnectionError extends APIError<undefined, undefined, undefined> {
  constructor({ message, cause }: { message?: string | undefined; cause?: Error | undefined }) {
    super(undefined, undefined, message || 'Connection error.', undefined);
    // in some environments the 'cause' property is already declared
    // @ts-ignore
    if (cause) this.cause = cause;
  }
}

export class APIConnectionTimeoutError extends APIConnectionError {
  constructor({ message }: { message?: string } = {}) {
    super({ message: message ?? 'Request timed out.' });
  }
}

/**
 * An error that opts into the SDK's retry policy: throw it (e.g. from
 * middleware) to have the attempt retried.
 *
 * Note that the request will only be retried when `maxRetries` has not been exhausted.
 */
export class RetryableError extends AnthropicError {
  constructor(message?: string, { cause }: { cause?: unknown } = {}) {
    super(message ?? 'Retryable error.');
    // in some environments the 'cause' property is already declared
    // @ts-ignore
    if (cause !== undefined) this.cause = cause;
  }
}

export class BadRequestError extends APIError<400, Headers> {}

export class AuthenticationError extends APIError<401, Headers> {}

export class PermissionDeniedError extends APIError<403, Headers> {}

export class NotFoundError extends APIError<404, Headers> {}

export class ConflictError extends APIError<409, Headers> {}

export class UnprocessableEntityError extends APIError<422, Headers> {}

export class RateLimitError extends APIError<429, Headers> {}

export class InternalServerError extends APIError<number, Headers> {}
