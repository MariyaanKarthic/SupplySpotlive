﻿import React, { useState } from 'react';
import { 
  Breadcrumb, 
  BreadcrumbItem, 
  BreadcrumbLink, 
  BreadcrumbList, 
  BreadcrumbPage, 
  BreadcrumbSeparator 
} from '@/components/ui/breadcrumb';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search, 
  Plus, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  Download, 
  Share2,
  FileText,
  Image,
  FileSpreadsheet,
  File,
  Upload,
  Trash2,
  Edit,
  Grid,
  List,
  Table as TableIcon
} from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

const documents = [
  {
    id: 1,
    name: 'Software License Agreement.pdf',
    vendor: 'TechCorp Solutions',
    type: 'Contract',
    category: 'Legal',
    size: '2.4 MB',
    uploadDate: '2023-11-15',
    uploadedBy: 'John Smith',
    status: 'Approved',
    version: '1.0',
    tags: ['License', 'Software', 'Annual'],
    fileType: 'pdf',
    description: 'Annual software licensing agreement for 2024'
  },
  {
    id: 2,
    name: 'Invoice_NOV_2023.pdf',
    vendor: 'Global Supplies Ltd',
    type: 'Invoice',
    category: 'Financial',
    size: '1.2 MB',
    uploadDate: '2023-11-20',
    uploadedBy: 'Sarah Johnson',
    status: 'Pending Review',
    version: '1.0',
    tags: ['Invoice', 'November', 'Materials'],
    fileType: 'pdf',
    description: 'Monthly invoice for raw materials supply'
  },
  {
    id: 3,
    name: 'Vendor_Certification.jpg',
    vendor: 'Premium Services Inc',
    type: 'Certificate',
    category: 'Compliance',
    size: '856 KB',
    uploadDate: '2023-11-25',
    uploadedBy: 'Mike Wilson',
    status: 'Approved',
    version: '2.1',
    tags: ['Certificate', 'ISO', 'Quality'],
    fileType: 'image',
    description: 'ISO 9001 quality certification document'
  },
  {
    id: 4,
    name: 'Transport_Quote.xlsx',
    vendor: 'Quick Logistics',
    type: 'Quote',
    category: 'Financial',
    size: '445 KB',
    uploadDate: '2023-11-28',
    uploadedBy: 'Emily Davis',
    status: 'Under Review',
    version: '1.2',
    tags: ['Quote', 'Transportation', 'Q4'],
    fileType: 'spreadsheet',
    description: 'Transportation services quote for Q4 2023'
  },
  {
    id: 5,
    name: 'Infrastructure_Specs.docx',
    vendor: 'Digital Systems Co',
    type: 'Specification',
    category: 'Technical',
    size: '1.8 MB',
    uploadDate: '2023-12-01',
    uploadedBy: 'David Brown',
    status: 'Approved',
    version: '3.0',
    tags: ['Specs', 'Infrastructure', 'Cloud'],
    fileType: 'document',
    description: 'Technical specifications for cloud infrastructure'
  },
  {
    id: 6,
    name: 'Insurance_Policy.pdf',
    vendor: 'TechCorp Solutions',
    type: 'Insurance',
    category: 'Legal',
    size: '3.2 MB',
    uploadDate: '2023-12-03',
    uploadedBy: 'Lisa Anderson',
    status: 'Expired',
    version: '1.0',
    tags: ['Insurance', 'Policy', 'Liability'],
    fileType: 'pdf',
    description: 'General liability insurance policy document'
  }
];

interface DocumentManagementProps {
  onNavigate?: (section: any) => void;
}

export function DocumentManagement({ onNavigate }: DocumentManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const [isViewDocumentOpen, setIsViewDocumentOpen] = useState(false);
  const [docViewMode, setDocViewMode] = useState<'card' | 'list' | 'table'>('table');

  const filteredDocuments = documents.filter(doc =>
    doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.vendor.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved': return 'default';
      case 'Pending Review': return 'secondary';
      case 'Under Review': return 'outline';
      case 'Expired': return 'destructive';
      case 'Rejected': return 'destructive';
      default: return 'outline';
    }
  };

  const getFileTypeIcon = (fileType: string) => {
    switch (fileType) {
      case 'pdf':
      case 'document': return <FileText className="w-5 h-5 text-red-500" />;
      case 'image': return <Image className="w-5 h-5 text-blue-500" />;
      case 'spreadsheet': return <FileSpreadsheet className="w-5 h-5 text-green-500" />;
      default: return <File className="w-5 h-5 text-gray-500" />;
    }
  };

  const handleViewDocument = (document: any) => {
    setSelectedDocument(document);
    setIsViewDocumentOpen(true);
  };

  const totalDocuments = documents.length;
  const pendingReview = documents.filter(doc => doc.status === 'Pending Review' || doc.status === 'Under Review').length;
  const approved = documents.filter(doc => doc.status === 'Approved').length;
  const expired = documents.filter(doc => doc.status === 'Expired').length;

  return (
    <div className="px-6 pb-6 space-y-6 w-full max-w-full overflow-x-hidden">
      {/* Sticky Header section with Breadcrumbs */}
      <div className="sticky top-0 bg-background/95 backdrop-blur z-20 border-b py-3 -mx-6 px-6 space-y-1.5 flex flex-col no-print">
        <Breadcrumb className="text-xs">
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink 
                onClick={() => onNavigate && onNavigate("home")} 
                className="cursor-pointer"
              >
                Dashboard
              </BreadcrumbLink>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Management</BreadcrumbPage>
            </BreadcrumbItem>
            <BreadcrumbSeparator />
            <BreadcrumbItem>
              <BreadcrumbPage>Documents</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
        <div className="flex items-center justify-between w-full">
          <h1 className="text-2xl sm:text-3xl font-semibold text-foreground">Document Management</h1>
          
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <Card className="border-l-4 border-l-blue-500 shadow-sm hover:shadow-md transition-all">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-semibold">Total Documents</p>
              <p className="text-xl font-bold text-foreground mt-0.5">{totalDocuments}</p>
              <p className="text-[11px] text-blue-600 font-medium">All uploads</p>
            </div>
            <div className="p-2.5 bg-blue-50 rounded-lg">
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500 shadow-sm hover:shadow-md transition-all">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-semibold">Pending Review</p>
              <p className="text-xl font-bold text-foreground mt-0.5">{pendingReview}</p>
              <p className="text-[11px] text-amber-600 font-medium">Awaiting verification</p>
            </div>
            <div className="p-2.5 bg-amber-50 rounded-lg">
              <Eye className="w-5 h-5 text-amber-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500 shadow-sm hover:shadow-md transition-all">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-semibold">Approved</p>
              <p className="text-xl font-bold text-foreground mt-0.5">{approved}</p>
              <p className="text-[11px] text-emerald-600 font-medium">Verified & active</p>
            </div>
            <div className="p-2.5 bg-emerald-50 rounded-lg">
              <FileText className="w-5 h-5 text-emerald-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-rose-500 shadow-sm hover:shadow-md transition-all">
          <CardContent className="p-3.5 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground font-semibold">Expired / Rejected</p>
              <p className="text-xl font-bold text-foreground mt-0.5">{expired}</p>
              <p className="text-[11px] text-rose-600 font-medium">Action required</p>
            </div>
            <div className="p-2.5 bg-rose-50 rounded-lg">
              <FileText className="w-5 h-5 text-rose-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card className="p-4">
        <div className="flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search documents..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" />
            Filters
          </Button>
        </div>
      </Card>

      {/* View Toggle Buttons */}
      <div className="flex items-center border rounded-md w-fit">
        <Button
          variant={docViewMode === 'card' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setDocViewMode('card')}
          className="rounded-r-none"
        >
          <Grid className="w-4 h-4" />
        </Button>
        <Button
          variant={docViewMode === 'list' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setDocViewMode('list')}
          className="rounded-none border-l border-r"
        >
          <List className="w-4 h-4" />
        </Button>
        <Button
          variant={docViewMode === 'table' ? 'default' : 'ghost'}
          size="sm"
          onClick={() => setDocViewMode('table')}
          className="rounded-l-none"
        >
          <TableIcon className="w-4 h-4" />
        </Button>
      </div>

      {/* Card View */}
      {docViewMode === 'card' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDocuments.map((document) => (
          <Card key={document.id} className="p-4 hover:shadow-md transition-shadow">
            <div className="space-y-3">
              {/* Document Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3 flex-1">
                  {getFileTypeIcon(document.fileType)}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate" title={document.name}>
                      {document.name}
                    </p>
                    <p className="text-xs text-muted-foreground">{document.size}</p>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => handleViewDocument(document)}>
                      <Eye className="w-4 h-4 mr-2" />
                      View Details
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit Info
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              {/* Document Info */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Vendor:</span>
                  <span className="text-sm font-medium">{document.vendor}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Type:</span>
                  <Badge variant="outline" className="text-xs">{document.type}</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Category:</span>
                  <span className="text-sm">{document.category}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Status:</span>
                  <Badge variant={getStatusColor(document.status)} className="text-xs">
                    {document.status}
                  </Badge>
                </div>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-1">
                {document.tags.slice(0, 3).map((tag, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {tag}
                  </Badge>
                ))}
                {document.tags.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{document.tags.length - 3}
                  </Badge>
                )}
              </div>

              {/* Upload Info */}
              <div className="pt-2 border-t text-xs text-muted-foreground">
                <p>Uploaded by {document.uploadedBy}</p>
                <p>{document.uploadDate} • v{document.version}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
      )}

      {/* List View */}
      {docViewMode === 'list' && (
        <div className="space-y-3">
          {filteredDocuments.map((document) => (
            <Card key={document.id} className="p-4 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    {getFileTypeIcon(document.fileType)}
                    <p className="font-semibold">{document.name}</p>
                    <Badge variant={document.status === 'Approved' ? 'default' : 'secondary'}>
                      {document.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>{document.vendor}</span>
                    <span>{document.type}</span>
                    <span>{document.uploadDate}</span>
                    <span>{document.size}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="ghost" onClick={() => setSelectedDocument(document)}>
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Table View */}
      {docViewMode === 'table' && (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-4 font-medium">Document Details</th>
                  <th className="text-left p-4 font-medium">Vendor</th>
                  <th className="text-left p-4 font-medium">Type</th>
                  <th className="text-left p-4 font-medium">Category</th>
                  <th className="text-left p-4 font-medium">Upload Date</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredDocuments.map((document) => (
                  <tr key={document.id} className="border-b hover:bg-muted/50">
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        {getFileTypeIcon(document.fileType)}
                        <div>
                          <p className="font-medium">{document.name}</p>
                          <p className="text-xs text-muted-foreground">{document.size}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{document.vendor}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{document.type}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{document.category}</span>
                    </td>
                    <td className="p-4">
                      <span className="text-sm">{document.uploadDate}</span>
                    </td>
                    <td className="p-4">
                      <Badge variant={document.status === 'Approved' ? 'default' : 'secondary'}>
                        {document.status}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <Button size="sm" variant="ghost" onClick={() => setSelectedDocument(document)}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Document Detail Sheet */}
      <Sheet open={isViewDocumentOpen} onOpenChange={setIsViewDocumentOpen}>
        <SheetContent className="sm:max-w-2xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle>Document Details</SheetTitle>
            <SheetDescription>
              View detailed information about this document.
            </SheetDescription>
          </SheetHeader>
          {selectedDocument && (
            <div className="space-y-4 mt-4">
              <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
                {getFileTypeIcon(selectedDocument.fileType)}
                <div>
                  <p className="font-medium">{selectedDocument.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedDocument.size}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Vendor</Label>
                  <p className="text-sm mt-1">{selectedDocument.vendor}</p>
                </div>
                <div>
                  <Label>Document Type</Label>
                  <p className="text-sm mt-1">{selectedDocument.type}</p>
                </div>
                <div>
                  <Label>Category</Label>
                  <p className="text-sm mt-1">{selectedDocument.category}</p>
                </div>
                <div>
                  <Label>Version</Label>
                  <p className="text-sm mt-1">v{selectedDocument.version}</p>
                </div>
                <div>
                  <Label>Upload Date</Label>
                  <p className="text-sm mt-1">{selectedDocument.uploadDate}</p>
                </div>
                <div>
                  <Label>Uploaded By</Label>
                  <p className="text-sm mt-1">{selectedDocument.uploadedBy}</p>
                </div>
                <div>
                  <Label>Status</Label>
                  <div className="mt-1">
                    <Badge variant={getStatusColor(selectedDocument.status)}>
                      {selectedDocument.status}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label>File Size</Label>
                  <p className="text-sm mt-1">{selectedDocument.size}</p>
                </div>
              </div>

              <div>
                <Label>Description</Label>
                <p className="text-sm mt-1">{selectedDocument.description}</p>
              </div>

              <div>
                <Label>Tags</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selectedDocument.tags.map((tag: string, index: number) => (
                    <Badge key={index} variant="secondary">{tag}</Badge>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 pt-4">
                <Button className="gap-2">
                  <Download className="w-4 h-4" />
                  Download
                </Button>
                <Button variant="outline" className="gap-2">
                  <Share2 className="w-4 h-4" />
                  Share
                </Button>
                <Button variant="outline" className="gap-2">
                  <Edit className="w-4 h-4" />
                  Edit Info
                </Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}