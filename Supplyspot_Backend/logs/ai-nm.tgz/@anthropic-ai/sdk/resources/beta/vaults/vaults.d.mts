import { APIResource } from "../../../core/resource.mjs";
import * as BetaAPI from "../beta.mjs";
import * as CredentialsAPI from "./credentials.mjs";
import { BetaManagedAgentsCredential, BetaManagedAgentsCredentialNetworkingParams, BetaManagedAgentsCredentialValidation, BetaManagedAgentsCredentialValidationStatus, BetaManagedAgentsCredentialsPageCursor, BetaManagedAgentsDeletedCredential, BetaManagedAgentsEnvironmentVariableAuthResponse, BetaManagedAgentsEnvironmentVariableCreateParams, BetaManagedAgentsEnvironmentVariableUpdateParams, BetaManagedAgentsInjectionLocationParams, BetaManagedAgentsInjectionLocationResponse, BetaManagedAgentsInjectionLocationUpdateParams, BetaManagedAgentsLimitedCredentialNetworkingParams, BetaManagedAgentsLimitedCredentialNetworkingResponse, BetaManagedAgentsMCPOAuthAuthResponse, BetaManagedAgentsMCPOAuthCreateParams, BetaManagedAgentsMCPOAuthRefreshParams, BetaManagedAgentsMCPOAuthRefreshResponse, BetaManagedAgentsMCPOAuthRefreshUpdateParams, BetaManagedAgentsMCPOAuthUpdateParams, BetaManagedAgentsMCPProbe, BetaManagedAgentsRefreshHTTPResponse, BetaManagedAgentsRefreshObject, BetaManagedAgentsStaticBearerAuthResponse, BetaManagedAgentsStaticBearerCreateParams, BetaManagedAgentsStaticBearerUpdateParams, BetaManagedAgentsTokenEndpointAuthBasicParam, BetaManagedAgentsTokenEndpointAuthBasicResponse, BetaManagedAgentsTokenEndpointAuthBasicUpdateParam, BetaManagedAgentsTokenEndpointAuthNoneParam, BetaManagedAgentsTokenEndpointAuthNoneResponse, BetaManagedAgentsTokenEndpointAuthPostParam, BetaManagedAgentsTokenEndpointAuthPostResponse, BetaManagedAgentsTokenEndpointAuthPostUpdateParam, BetaManagedAgentsUnrestrictedCredentialNetworkingParams, BetaManagedAgentsUnrestrictedCredentialNetworkingResponse, CredentialArchiveParams, CredentialCreateParams, CredentialDeleteParams, CredentialListParams, CredentialMCPOAuthValidateParams, CredentialRetrieveParams, CredentialUpdateParams, Credentials } from "./credentials.mjs";
import { APIPromise } from "../../../core/api-promise.mjs";
import { PageCursor, type PageCursorParams, PagePromise } from "../../../core/pagination.mjs";
import { RequestOptions } from "../../../internal/request-options.mjs";
export declare class Vaults extends APIResource {
    credentials: CredentialsAPI.Credentials;
    /**
     * Create Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.create({
     *     display_name: 'Example vault',
     *   });
     * ```
     */
    create(params: VaultCreateParams, options?: RequestOptions): APIPromise<BetaManagedAgentsVault>;
    /**
     * Get Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.retrieve(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    retrieve(vaultID: string, params?: VaultRetrieveParams | null | undefined, options?: RequestOptions): APIPromise<BetaManagedAgentsVault>;
    /**
     * Update Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.update(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    update(vaultID: string, params: VaultUpdateParams, options?: RequestOptions): APIPromise<BetaManagedAgentsVault>;
    /**
     * List Vaults
     *
     * @example
     * ```ts
     * // Automatically fetches more pages as needed.
     * for await (const betaManagedAgentsVault of client.beta.vaults.list()) {
     *   // ...
     * }
     * ```
     */
    list(params?: VaultListParams | null | undefined, options?: RequestOptions): PagePromise<BetaManagedAgentsVaultsPageCursor, BetaManagedAgentsVault>;
    /**
     * Delete Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsDeletedVault =
     *   await client.beta.vaults.delete(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    delete(vaultID: string, params?: VaultDeleteParams | null | undefined, options?: RequestOptions): APIPromise<BetaManagedAgentsDeletedVault>;
    /**
     * Archive Vault
     *
     * @example
     * ```ts
     * const betaManagedAgentsVault =
     *   await client.beta.vaults.archive(
     *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
     *   );
     * ```
     */
    archive(vaultID: string, params?: VaultArchiveParams | null | undefined, options?: RequestOptions): APIPromise<BetaManagedAgentsVault>;
}
export type BetaManagedAgentsVaultsPageCursor = PageCursor<BetaManagedAgentsVault>;
/**
 * Confirmation of a deleted vault.
 */
export interface BetaManagedAgentsDeletedVault {
    /**
     * Unique identifier of the deleted vault.
     */
    id: string;
    type: 'vault_deleted';
}
/**
 * A vault that stores credentials for use by agents during sessions.
 */
export interface BetaManagedAgentsVault {
    /**
     * Unique identifier for the vault.
     */
    id: string;
    /**
     * When the vault was archived. Null if not archived.
     */
    archived_at: string | null;
    /**
     * A timestamp in RFC 3339 format
     */
    created_at: string;
    /**
     * Human-readable name for the vault.
     */
    display_name: string;
    /**
     * Arbitrary key-value metadata attached to the vault.
     */
    metadata: {
        [key: string]: string;
    };
    type: 'vault';
    /**
     * A timestamp in RFC 3339 format
     */
    updated_at: string;
}
export interface VaultCreateParams {
    /**
     * Body param: Human-readable name for the vault. 1-255 characters.
     */
    display_name: string;
    /**
     * Body param: Arbitrary key-value metadata to attach to the vault. Maximum 16
     * pairs, keys up to 64 chars, values up to 512 chars.
     */
    metadata?: {
        [key: string]: string;
    };
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Header param: Optional header to select the Workspace for this request. The
     * value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export interface VaultRetrieveParams {
    /**
     * Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Optional header to select the Workspace for this request. The value is a
     * Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export interface VaultUpdateParams {
    /**
     * Body param: Updated human-readable name for the vault. 1-255 characters.
     */
    display_name?: string | null;
    /**
     * Body param: Metadata patch. Set a key to a string to upsert it, or to null to
     * delete it. Omitted keys are preserved.
     */
    metadata?: {
        [key: string]: string | null;
    } | null;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Header param: Optional header to select the Workspace for this request. The
     * value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export interface VaultListParams extends PageCursorParams {
    /**
     * Query param: Whether to include archived vaults in the results.
     */
    include_archived?: boolean;
    /**
     * Header param: Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Header param: Optional header to select the Workspace for this request. The
     * value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export interface VaultDeleteParams {
    /**
     * Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Optional header to select the Workspace for this request. The value is a
     * Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export interface VaultArchiveParams {
    /**
     * Optional header to specify the beta version(s) you want to use.
     */
    betas?: Array<BetaAPI.AnthropicBeta>;
    /**
     * Optional header to select the Workspace for this request. The value is a
     * Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).
     *
     * Only needed for credentials that can act on more than one Workspace. A
     * credential that belongs to a specific Workspace may omit it; if sent, it must
     * match that Workspace.
     */
    workspace_id?: string;
}
export declare namespace Vaults {
    export { type BetaManagedAgentsDeletedVault as BetaManagedAgentsDeletedVault, type BetaManagedAgentsVault as BetaManagedAgentsVault, type BetaManagedAgentsVaultsPageCursor as BetaManagedAgentsVaultsPageCursor, type VaultCreateParams as VaultCreateParams, type VaultRetrieveParams as VaultRetrieveParams, type VaultUpdateParams as VaultUpdateParams, type VaultListParams as VaultListParams, type VaultDeleteParams as VaultDeleteParams, type VaultArchiveParams as VaultArchiveParams, };
    export { Credentials as Credentials, type BetaManagedAgentsCredential as BetaManagedAgentsCredential, type BetaManagedAgentsCredentialNetworkingParams as BetaManagedAgentsCredentialNetworkingParams, type BetaManagedAgentsCredentialValidation as BetaManagedAgentsCredentialValidation, type BetaManagedAgentsCredentialValidationStatus as BetaManagedAgentsCredentialValidationStatus, type BetaManagedAgentsDeletedCredential as BetaManagedAgentsDeletedCredential, type BetaManagedAgentsEnvironmentVariableAuthResponse as BetaManagedAgentsEnvironmentVariableAuthResponse, type BetaManagedAgentsEnvironmentVariableCreateParams as BetaManagedAgentsEnvironmentVariableCreateParams, type BetaManagedAgentsEnvironmentVariableUpdateParams as BetaManagedAgentsEnvironmentVariableUpdateParams, type BetaManagedAgentsInjectionLocationParams as BetaManagedAgentsInjectionLocationParams, type BetaManagedAgentsInjectionLocationResponse as BetaManagedAgentsInjectionLocationResponse, type BetaManagedAgentsInjectionLocationUpdateParams as BetaManagedAgentsInjectionLocationUpdateParams, type BetaManagedAgentsLimitedCredentialNetworkingParams as BetaManagedAgentsLimitedCredentialNetworkingParams, type BetaManagedAgentsLimitedCredentialNetworkingResponse as BetaManagedAgentsLimitedCredentialNetworkingResponse, type BetaManagedAgentsMCPOAuthAuthResponse as BetaManagedAgentsMCPOAuthAuthResponse, type BetaManagedAgentsMCPOAuthCreateParams as BetaManagedAgentsMCPOAuthCreateParams, type BetaManagedAgentsMCPOAuthRefreshParams as BetaManagedAgentsMCPOAuthRefreshParams, type BetaManagedAgentsMCPOAuthRefreshResponse as BetaManagedAgentsMCPOAuthRefreshResponse, type BetaManagedAgentsMCPOAuthRefreshUpdateParams as BetaManagedAgentsMCPOAuthRefreshUpdateParams, type BetaManagedAgentsMCPOAuthUpdateParams as BetaManagedAgentsMCPOAuthUpdateParams, type BetaManagedAgentsMCPProbe as BetaManagedAgentsMCPProbe, type BetaManagedAgentsRefreshHTTPResponse as BetaManagedAgentsRefreshHTTPResponse, type BetaManagedAgentsRefreshObject as BetaManagedAgentsRefreshObject, type BetaManagedAgentsStaticBearerAuthResponse as BetaManagedAgentsStaticBearerAuthResponse, type BetaManagedAgentsStaticBearerCreateParams as BetaManagedAgentsStaticBearerCreateParams, type BetaManagedAgentsStaticBearerUpdateParams as BetaManagedAgentsStaticBearerUpdateParams, type BetaManagedAgentsTokenEndpointAuthBasicParam as BetaManagedAgentsTokenEndpointAuthBasicParam, type BetaManagedAgentsTokenEndpointAuthBasicResponse as BetaManagedAgentsTokenEndpointAuthBasicResponse, type BetaManagedAgentsTokenEndpointAuthBasicUpdateParam as BetaManagedAgentsTokenEndpointAuthBasicUpdateParam, type BetaManagedAgentsTokenEndpointAuthNoneParam as BetaManagedAgentsTokenEndpointAuthNoneParam, type BetaManagedAgentsTokenEndpointAuthNoneResponse as BetaManagedAgentsTokenEndpointAuthNoneResponse, type BetaManagedAgentsTokenEndpointAuthPostParam as BetaManagedAgentsTokenEndpointAuthPostParam, type BetaManagedAgentsTokenEndpointAuthPostResponse as BetaManagedAgentsTokenEndpointAuthPostResponse, type BetaManagedAgentsTokenEndpointAuthPostUpdateParam as BetaManagedAgentsTokenEndpointAuthPostUpdateParam, type BetaManagedAgentsUnrestrictedCredentialNetworkingParams as BetaManagedAgentsUnrestrictedCredentialNetworkingParams, type BetaManagedAgentsUnrestrictedCredentialNetworkingResponse as BetaManagedAgentsUnrestrictedCredentialNetworkingResponse, type BetaManagedAgentsCredentialsPageCursor as BetaManagedAgentsCredentialsPageCursor, type CredentialCreateParams as CredentialCreateParams, type CredentialRetrieveParams as CredentialRetrieveParams, type CredentialUpdateParams as CredentialUpdateParams, type CredentialListParams as CredentialListParams, type CredentialDeleteParams as CredentialDeleteParams, type CredentialArchiveParams as CredentialArchiveParams, type CredentialMCPOAuthValidateParams as CredentialMCPOAuthValidateParams, };
}
//# sourceMappingURL=vaults.d.mts.map